#!/usr/bin/env bash

cd ../../scripts
./pre-build.sh
