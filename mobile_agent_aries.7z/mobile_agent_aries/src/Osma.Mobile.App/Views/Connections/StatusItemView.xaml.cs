﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace Osma.Mobile.App.Views.Connections
{
    public partial class StatusItemView : ContentView
    {
        public StatusItemView()
        {
            InitializeComponent();
        }
    }
}
