﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace Osma.Mobile.App.Views.Connections
{
    public partial class ErrorItemView : ContentView
    {
        public ErrorItemView()
        {
            InitializeComponent();
        }
    }
}
