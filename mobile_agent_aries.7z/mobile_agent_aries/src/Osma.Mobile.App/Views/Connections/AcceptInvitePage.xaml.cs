﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Osma.Mobile.App.Views.Connections
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class AcceptInvitePage : ContentPage
	{
		public AcceptInvitePage ()
		{
			InitializeComponent ();
		}
	}
}