﻿using System;
namespace Osma.Mobile.App
{
    public interface IBaseUrl
    {
        string Get();
    }
}
